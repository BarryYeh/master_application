var classArMapGPSCoords =
[
    [ "ArMapGPSCoords", "classArMapGPSCoords.html#a85ea3578b4213accf5e70991780eddbb", null ],
    [ "ArMapGPSCoords", "classArMapGPSCoords.html#aaee521f580d2a8aaa3a721df1c08787a", null ],
    [ "convertLLA2MapCoords", "classArMapGPSCoords.html#ae5bc854889450db24b9da00b050ca937", null ],
    [ "convertLLA2MapCoords", "classArMapGPSCoords.html#a525a511032fca5a38efefb1495c57197", null ],
    [ "convertMap2LLACoords", "classArMapGPSCoords.html#ae2fa8e14ec073397223177ece2fd4a54", null ],
    [ "setOrigin", "classArMapGPSCoords.html#a196b518a5b51bc5f80d92718eadf8ea2", null ],
    [ "myOriginECEF", "classArMapGPSCoords.html#a17d0d5636a2147f980973b1c417afb27", null ],
    [ "myOriginLLA", "classArMapGPSCoords.html#a6d5b0db26a8ab64c7c4ce82af4ab9bac", null ],
    [ "myOriginSet", "classArMapGPSCoords.html#a1c825f002001b286af9e03df44a61074", null ]
];