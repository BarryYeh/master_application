var classArSZSeriesPacketReceiver =
[
    [ "ArSZSeriesPacketReceiver", "classArSZSeriesPacketReceiver.html#a193901449b901d1e399495c002ad5d7d", null ],
    [ "~ArSZSeriesPacketReceiver", "classArSZSeriesPacketReceiver.html#ad6a73bc7f6c919a60a697c7a93facb59", null ],
    [ "CRC16", "classArSZSeriesPacketReceiver.html#aa8f2a9b94b6f8bd1683e9bfbde0083b7", null ],
    [ "getDeviceConnection", "classArSZSeriesPacketReceiver.html#a3b2ed47a9f6c80b71fbfd03ec27a238b", null ],
    [ "receivePacket", "classArSZSeriesPacketReceiver.html#aec2734339b52378d278492ba8495b396", null ],
    [ "setDeviceConnection", "classArSZSeriesPacketReceiver.html#a04d92507ae98f45c6d2d871d72c71ae7", null ],
    [ "setmyInfoLogLevel", "classArSZSeriesPacketReceiver.html#ac131ef81a51be59497030f54d0897151", null ],
    [ "setmyIsSZ00", "classArSZSeriesPacketReceiver.html#af3ab235c4a1992db5b255ccff1803e1c", null ],
    [ "setmyName", "classArSZSeriesPacketReceiver.html#a1e0be086643bdc721725546206d90452", null ],
    [ "myConn", "classArSZSeriesPacketReceiver.html#a8facbad1141eabbd1441df65f341ef49", null ],
    [ "myInfoLogLevel", "classArSZSeriesPacketReceiver.html#a5ff89d9297d847a3e833687b39ad0b44", null ],
    [ "myIsSZ00", "classArSZSeriesPacketReceiver.html#a83f994cb8e4175003c0c787449726d7b", null ],
    [ "myName", "classArSZSeriesPacketReceiver.html#a216180c6e5aa4fe464f49d678b91f532", null ],
    [ "myNameLength", "classArSZSeriesPacketReceiver.html#a9a92ed28a0aa56cab984177ed558cfa6", null ],
    [ "myPacket", "classArSZSeriesPacketReceiver.html#acf36d06d571bb81d3674114f97d67629", null ],
    [ "myPrevCrc", "classArSZSeriesPacketReceiver.html#a8af014a0bc54c8df29776f25dc97bca7", null ],
    [ "myReadBuf", "classArSZSeriesPacketReceiver.html#aa16d30d5bf75f526e3ab7b47325fbb96", null ],
    [ "myReadCount", "classArSZSeriesPacketReceiver.html#ac21593929141f0ec78266f2cedd38490", null ]
];