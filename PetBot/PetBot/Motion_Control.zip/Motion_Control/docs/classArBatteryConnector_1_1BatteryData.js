var classArBatteryConnector_1_1BatteryData =
[
    [ "BatteryData", "classArBatteryConnector_1_1BatteryData.html#ab4ce57df119041702d3bc2c5d9c9730f", null ],
    [ "~BatteryData", "classArBatteryConnector_1_1BatteryData.html#aefe6fc5e9317efbc429d787a014fb569", null ],
    [ "myAutoConn", "classArBatteryConnector_1_1BatteryData.html#a040770f82402b0f710dc513596a69ba1", null ],
    [ "myBattery", "classArBatteryConnector_1_1BatteryData.html#a180647098b21d5fa602b40d5cffff20a", null ],
    [ "myBaud", "classArBatteryConnector_1_1BatteryData.html#a66530442a968915a0199c32a44aa5800", null ],
    [ "myConn", "classArBatteryConnector_1_1BatteryData.html#a3995d7137eaaa9bd0cf5bca63d021e92", null ],
    [ "myConnect", "classArBatteryConnector_1_1BatteryData.html#ad59f297c87355e5b313c617811c8d152", null ],
    [ "myConnectReallySet", "classArBatteryConnector_1_1BatteryData.html#a6e5be0d26d19fe662b76564341e170c4", null ],
    [ "myNumber", "classArBatteryConnector_1_1BatteryData.html#ac39be36fdc461babba9c4a34e1e1509b", null ],
    [ "myPort", "classArBatteryConnector_1_1BatteryData.html#a19d876a6a2da3b986f874261ed8604c5", null ],
    [ "myPortType", "classArBatteryConnector_1_1BatteryData.html#a96a72486cc61ce3706d19377e2ef868f", null ],
    [ "myRemoteTcpPort", "classArBatteryConnector_1_1BatteryData.html#a443896f4005e4d95cd3d1a73547e03d1", null ],
    [ "myRemoteTcpPortReallySet", "classArBatteryConnector_1_1BatteryData.html#a59c246458850d43de555d7f46473987f", null ],
    [ "myType", "classArBatteryConnector_1_1BatteryData.html#afe78ad21dc9c316083d798f3f9196aa5", null ]
];