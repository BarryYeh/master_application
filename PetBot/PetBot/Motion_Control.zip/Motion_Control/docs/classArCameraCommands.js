var classArCameraCommands =
[
    [ "CAMERA_MODE_UPDATED", "classArCameraCommands.html#a13d9ff41c501b33d7bf07557b58dae7d", null ],
    [ "GET_CAMERA_DATA", "classArCameraCommands.html#aafce83a8e187656fe7309fac2b67f5dd", null ],
    [ "GET_CAMERA_DATA_INT", "classArCameraCommands.html#a8fadac548f658e156ce09fd9b923f481", null ],
    [ "GET_CAMERA_INFO", "classArCameraCommands.html#a05a88bf890aa4ebc3a271af3b4c52843", null ],
    [ "GET_CAMERA_INFO_INT", "classArCameraCommands.html#a97b857e8ae657bc191092719eb19052d", null ],
    [ "GET_CAMERA_MODE_LIST", "classArCameraCommands.html#a4ffa289dd51b1b8086aa6b5c15d05282", null ],
    [ "GET_DISPLAY", "classArCameraCommands.html#aa158a07734092504733131cd0842e33b", null ],
    [ "GET_PICTURE", "classArCameraCommands.html#acf12225bbcaed71ea4c106d3a7a25273", null ],
    [ "GET_PICTURE_OPTIM", "classArCameraCommands.html#a780ce827c893ee8cadc2adf546106461", null ],
    [ "GET_SNAPSHOT", "classArCameraCommands.html#a79fad5a855b447f2550500f5a4babb6d", null ],
    [ "GET_SNAPSHOT_PLAIN", "classArCameraCommands.html#a1ad55b6642f770758c066b990168c7bd", null ],
    [ "GET_VIDEO", "classArCameraCommands.html#a04c498007b828e3f5a02f14eb73c1878", null ],
    [ "RESET_CAMERA", "classArCameraCommands.html#acf15697dba03f78b0a830ba3bdc7e64b", null ],
    [ "SET_CAMERA_ABS", "classArCameraCommands.html#a9e386e8fff2cbb34bb48e27111bf57ee", null ],
    [ "SET_CAMERA_ABS_INT", "classArCameraCommands.html#a31fae667ddeae1cc96cd28c0dc49292c", null ],
    [ "SET_CAMERA_MODE", "classArCameraCommands.html#a58001cb278e8f81b6c4bb9acda79aa24", null ],
    [ "SET_CAMERA_PCT", "classArCameraCommands.html#a527b9dd22ae3dd8db1e796a99fdb36ad", null ],
    [ "SET_CAMERA_PCT_INT", "classArCameraCommands.html#ae653da5cae4995a393bccdb2207f2823", null ],
    [ "SET_CAMERA_REL", "classArCameraCommands.html#a68901ea9566f0c8be592577bf2b7d7ea", null ],
    [ "SET_CAMERA_REL_INT", "classArCameraCommands.html#ad36d1b013626f65f71919a8577ec725b", null ]
];