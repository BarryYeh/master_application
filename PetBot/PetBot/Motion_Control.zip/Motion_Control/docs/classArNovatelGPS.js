var classArNovatelGPS =
[
    [ "ArNovatelGPS", "classArNovatelGPS.html#a3664fc4f30f07827ac9575808b2c54b4", null ],
    [ "~ArNovatelGPS", "classArNovatelGPS.html#ad5658c0420d3bc0481269e4a7455bdbe", null ],
    [ "handleNovatelGPGGA", "classArNovatelGPS.html#a1b4e585e953a04e77b9f096e9e0ee072", null ],
    [ "initDevice", "classArNovatelGPS.html#adcc05fa40c7a92671afce67a9182a81d", null ],
    [ "myNovatelGPGGAHandler", "classArNovatelGPS.html#a4798917e4c03674f3ceb0747426a579b", null ]
];