var classArRetFunctor =
[
    [ "~ArRetFunctor", "classArRetFunctor.html#a266beb798a65cbe5a2f09c41f8077ad0", null ],
    [ "invoke", "classArRetFunctor.html#aa444b50e3a24ec21352a663aed0c17f2", null ],
    [ "invokeR", "classArRetFunctor.html#a941fc1c54f2d841f11c9dd899e15e88d", null ]
];