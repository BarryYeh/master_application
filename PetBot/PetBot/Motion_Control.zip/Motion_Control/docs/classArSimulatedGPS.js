var classArSimulatedGPS =
[
    [ "ArSimulatedGPS", "classArSimulatedGPS.html#a022a3baf6292a66b85cb037abaa180fc", null ],
    [ "~ArSimulatedGPS", "classArSimulatedGPS.html#a5d4f6cffa40902f864fda461dc6fe620", null ],
    [ "clearDummyPosition", "classArSimulatedGPS.html#ab5087eea25bed132ac7defc7c7a8005b", null ],
    [ "clearPosition", "classArSimulatedGPS.html#aaa482eab35b309847a6169794cac3362", null ],
    [ "connect", "classArSimulatedGPS.html#aa144b5907d30d66af0b4f74dbc3a3822", null ],
    [ "initDevice", "classArSimulatedGPS.html#aecf3a56cf25780f587d0df26125406ea", null ],
    [ "read", "classArSimulatedGPS.html#a1e870a3cb9d19b4c90944ce201fd85be", null ],
    [ "setDummyPosition", "classArSimulatedGPS.html#af19bbea1ad3926cd884ce7edfe95fbd6", null ],
    [ "setDummyPosition", "classArSimulatedGPS.html#a9f8cb5343647de718763511360e4e4d4", null ],
    [ "setDummyPosition", "classArSimulatedGPS.html#a684700f2452ee9df84f71d1856ca2b2e", null ],
    [ "setDummyPositionFromArgs", "classArSimulatedGPS.html#a089676479db28ae7587184229da47a1b", null ]
];