var classArModeRobotStatus =
[
    [ "ArModeRobotStatus", "classArModeRobotStatus.html#afe442a314b2efa2cf7057a2b9eaf1a3f", null ],
    [ "activate", "classArModeRobotStatus.html#a8194ffbd159963a814b008aece6ce034", null ],
    [ "deactivate", "classArModeRobotStatus.html#a9c455143528b9d892cc5fe3a83d5f46a", null ],
    [ "handleDebugMessage", "classArModeRobotStatus.html#a18ff98c1be18a6c70b722a89050bf0c7", null ],
    [ "handleSafetyStatePacket", "classArModeRobotStatus.html#ad209866f92b0477c23c5c366ded5d50f", null ],
    [ "handleSafetyWarningPacket", "classArModeRobotStatus.html#a7a01637cadb40d0fabd1761bd34e883b", null ],
    [ "help", "classArModeRobotStatus.html#ac1a3adb284a03d340ba0c27789fbb29d", null ],
    [ "printFlags", "classArModeRobotStatus.html#af2ffc1526675bba2a8d7e063964892ca", null ],
    [ "printFlagsHeader", "classArModeRobotStatus.html#a6d8ce62741994f36d6ec4bdd8777e3d7", null ],
    [ "safetyStateName", "classArModeRobotStatus.html#ade15eae5ab2e27980983e65a01e6f4b7", null ],
    [ "toggleShutdown", "classArModeRobotStatus.html#ab057c7ad993e9dde43ed56fc889ca61c", null ],
    [ "userTask", "classArModeRobotStatus.html#ae6a0fc7e09e6572ef244ba5a77615d69", null ],
    [ "myBatteryShutdown", "classArModeRobotStatus.html#ad0e30bc1d9170019719a631a9f8f2ae0", null ],
    [ "myDebugMessageCB", "classArModeRobotStatus.html#a1bcf2ffcdaca355d23ab9855b560df12", null ],
    [ "myRobot", "classArModeRobotStatus.html#a27c066fb765f5282bc4dab142f455bc0", null ],
    [ "mySafetyStateCB", "classArModeRobotStatus.html#aeffa1e07788daae202fa5235a61222f4", null ],
    [ "mySafetyWarningCB", "classArModeRobotStatus.html#afce30b53c02cd01b6d14740e80e5e887", null ],
    [ "myToggleShutdownCB", "classArModeRobotStatus.html#a1df34ef97b983e0213481ed41d454471", null ]
];