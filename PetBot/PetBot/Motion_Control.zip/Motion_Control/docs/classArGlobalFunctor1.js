var classArGlobalFunctor1 =
[
    [ "ArGlobalFunctor1", "classArGlobalFunctor1.html#ab71f18da72efa9f56cf6eadde85e4ab3", null ],
    [ "ArGlobalFunctor1", "classArGlobalFunctor1.html#a08fa5d462244b568dacb000838a646dd", null ],
    [ "ArGlobalFunctor1", "classArGlobalFunctor1.html#a3f7536877bb361ea74b9fd4789eb7221", null ],
    [ "~ArGlobalFunctor1", "classArGlobalFunctor1.html#a41e054db7a5d38a233d3cea71d7d4cc0", null ],
    [ "invoke", "classArGlobalFunctor1.html#adc31735285c219c61ac23f2200bba7bd", null ],
    [ "invoke", "classArGlobalFunctor1.html#ad94dff9851a225a56bfd4a544139ad09", null ],
    [ "setP1", "classArGlobalFunctor1.html#ade674c66329b8caf6ed19596adbb6eae", null ],
    [ "myFunc", "classArGlobalFunctor1.html#a3d80dd4476176cea5e88cf80a4f8970a", null ],
    [ "myP1", "classArGlobalFunctor1.html#a9366f711684ccab50703e1d81c6592b6", null ]
];