var classArFunctorASyncTask =
[
    [ "ArFunctorASyncTask", "classArFunctorASyncTask.html#a95d0f839307f31ed8763571da8f7156c", null ],
    [ "~ArFunctorASyncTask", "classArFunctorASyncTask.html#aca9d3a8f469363f29225247cc30c4e68", null ],
    [ "runThread", "classArFunctorASyncTask.html#a1fe7b4bb0b9fe8e7bfbee46fe7cc3f61", null ],
    [ "myFunc", "classArFunctorASyncTask.html#ac87ce4371e3ad78954e457550d8b88fb", null ]
];