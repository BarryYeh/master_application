var structArNMEAParser_1_1Message =
[
    [ "id", "structArNMEAParser_1_1Message.html#a8a0a99a7fb7d0cb7bc2bb16403b997e3", null ],
    [ "message", "structArNMEAParser_1_1Message.html#a1ecfbccd256c12346a21a7c31752d802", null ],
    [ "prefix", "structArNMEAParser_1_1Message.html#a2d403bd7f4343906a7b28e75d902d2af", null ],
    [ "timeParseStarted", "structArNMEAParser_1_1Message.html#ada8be1649b516126178f219709e1a596", null ]
];